
<div class="footer">
	<hr/>
&copy2018. Developed by Charles Kapiya Mukupa : BIT1510297.
<br/>
Online Voting System.
<br/>
Final Year Project 2018. University Of Lusaka
<br/>
Contact: <a href="tel:+260979848064">+260 979-848064</a> | Email: <a href="mailto:charlesmukupa@gmail.com">charlesmukupa@gmail.com</a>

</div>
