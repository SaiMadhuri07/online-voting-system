$(document).ready(function(){
	$(".img").click(function(){
		alert("Hello World");
	});
});